aaa = c(12, 2, 4)
install.packages(aaa)

library("beepr")
beep(2)

list.files() # 작업폴더의 폴더 및 파일 목록 조회
list.files(pattern = "data")

# 작업폴더 아래에 있는 data폴더의 내용을 조회
list.files(path = "data")
list.files(pattern = "AWS")
list.files(pattern = "AWS",
           recursive = TRUE) # 하위 폴더 까지 조회
list.files(path = "data",
           full.names = TRUE) # 전체 경로(wd 기준)

file_path = list.files(pattern = "AWS",
                       recursive = TRUE)
file_path
file_path[2]
aws = read.csv(file_path[2], sep = "#")
head(aws, 2)

bike = read.csv("C:/Users/Encaion/Desktop/R_class/bike.csv")
head(bike, 2)

# path_2 = "C:\Users\Encaion\Desktop\R_class\bike.csv"
path_2 = "C://Users//Encaion//Desktop//R_class//bike.csv"
normalizePath(path_2) # 암기 금지

listt = list(aa = 1:3,
             bb = matrix(1:4, nrow = 2),
             cc = list(dd = data.frame(v1 = 2:4,
                                       v2 = 4:6),
                       ee = c("a", "b", "c")))
listt
listt[1]
listt[[1]]
listt["aa"]
listt[["aa"]]

names(listt)
str(listt)
listt$aa[c(1, 3)]
listt$cc$ee
listt[["cc"]][["ee"]]

seq(from = 1, to = 3, length.out = 8)
seq(from = 1, to = 3, length.out = 9)


head(aws, 2)

# Q. aws객체의 변수를 AWS_ID, TA, Wind, TM, X. 순으로 정리하여
#    aws_2 객체에 저장하고 이를 확인하시오.
aws_2 = aws[, c(1, 3, 4, 2, 5)]
aws_2 = aws[, c("AWS_ID", "TA", "Wind", "TM", "X.")]
head(aws_2, 2)

aws[, "X."]
aws[, c("Wind", "AWS_ID")]

bbb = function(){
    print("Rloha")
}
bbb()

ccc = function(x){
    print(x)
}
ccc()
ccc(34567)

# ▶ 대괄호: 색인, 추출
# ▶ 중괄호: 여러 줄의 코드를 묶는 용도
# ▶ 소괄호: 함수의 인자를 묶음, 연산의 우선순위 지정
3 * 5 + 2
3 * (5 + 2)

data("diamonds", package = "ggplot2")
head(diamonds, 2)

table(diamonds$cut, diamonds$clarity)

table(diamonds["cut"])
# Q. sum() 함수를 활용하여 cut 변수의 
# 각 원소 등장 비율을 계산하시오.
table(diamonds["cut"]) / sum(table(diamonds["cut"]))
table(diamonds["cut"]) / nrow(diamonds)

prop.table(table(diamonds["cut"]))
prop.table(table(diamonds$cut,
                 diamonds$clarity), margin = 1)
prop.table(table(diamonds$cut,
                 diamonds$clarity), margin = 2)

round(prop.table(table(diamonds$cut,
                       diamonds$clarity),
                 margin = 1), 3)

round(prop.table(table(diamonds$cut,
                       diamonds$clarity),
                 margin = 2), 3)

data("airquality")
df = airquality

length(3:6)
length(c("a", "b", "c"))
length(unique(df$Month))

quantile(df$Wind)
quantile(df$Wind, probs = 0.99)
quantile(df$Wind, probs = c(0.05, 0.95))

df_dup = data.frame(v1 = c(1, 1, 2, 2),
                    v2 = c("a", "a", "b", "b"))
df_dup
unique(df_dup) # 중복 row 제거

elec = read.csv("elec_load.csv")
head(elec, 2)
aggregate(data = elec, X20HR ~ YEAR + MONTH, 
          FUN = "mean")

mean_p = function(x){
    mean(x) + 30000
}
aggregate(data = elec, X20HR ~ YEAR + MONTH, 
          FUN = "mean_p")


# 2개 이상의 변수를 요약하는 방법?
# 1) cbind()
elec_a12 = aggregate(data = elec, X12HR ~ YEAR, FUN = "mean")
elec_a14 = aggregate(data = elec, X14HR ~ YEAR, FUN = "mean")
head(elec_a12)

elec_a = cbind(elec_a12, elec_a14)
head(elec_a, 2)

# 2) new column
elec_a = aggregate(data = elec, X12HR ~ YEAR, FUN = "mean")
elec_a14 = aggregate(data = elec, X14HR ~ YEAR, FUN = "mean")
head(elec_a14)

elec_a[, "X14HR"] = elec_a14$X14HR
head(elec_a, 2)

# 3) formula 응용
elec_a = aggregate(data = elec[, c("YEAR", "X12HR", "X14HR")],
                   . ~ YEAR, FUN = "mean")
head(elec_a, 2)


sample(1:45, size = 6)

set.seed(500)
sample(1:45, size = 6)

set.seed(9999999)
sample(1:45, size = 6)

set.seed(123)
sample(1:45, size = 6)
1 + 3

# Q1. 1부터 100 사이의 자연수 100개에서 
# 20개를 추출하고 이를 5세 단위로 구분하여보시오.
# ※ 데이터프레임 활용
# ※ 추출은 sample() 함수 사용, seed는 123
set.seed(123)
df = data.frame(obs = 1:20,
                age = sample(1:100, size = 20))
head(df, 2)
df[, "age_g1"] = cut(df$age, breaks = seq(1, 100, 5))
df[, "age_g2"] = cut(df$age, breaks = seq(1, 100, 5),
                     right = FALSE)
df[, "age_g3"] = cut(df$age, breaks = seq(0, 100, 5),
                     right = FALSE)
df[, "age_g4"] = df$age %/% 5 # 5로 나눈 몫
df[, "age_g5"] = df$age %/% 5 * 5
head(df, 2)

for(number in 1:3){
    print(number)
}
print(1)
print(2)
print(3)
for(n in 1:3){
    print(n)
}

for(n in letters){
    print(n)
}
LETTERS

df_1 = data.frame(aa = letters[1:4],
                  bb = 1:4)
for(num in 1:4){
    df_1[num, "new_column"] = num * 2
}
df_1

df_1 = data.frame(aa = letters[1:4],
                  bb = 1:4)
for(num in 1:4){
    df_1[num, "new_column"] = num * 2
    print(df_1)
    Sys.sleep(2)
}
df_1

for(i in 1:4){
    for(j in 101:104){
        print(i + j)
    }
}

for(i in 2:5){
    i
}

n = 3
if(n == 3){
    print("우왕!!!")
}
# if() 조건문은 함수내의 조건검사 결과가 TRUE일 경우
# 첫 번째 중괄호 내부의 코드가 실행됨.
# 조건검사 결과가 FALSE일 경우 else가 없으면 반응X
# else + 중괄호가 있는 경우 해당 중괄호의 내용이 실행됨

n = 5
if(n == 3){
    print("우왕!!!")
} else {
    print("으엑!!")
}

df_1 = data.frame(aa = letters[1:4],
                  bb = 1:4)
df_1
df_1[df_1$bb >= 3, ]

df_1[c(3, 4), ]
df_1[c(FALSE, FALSE, TRUE, TRUE), ]

df_1[3:4,]


paste("a", "b", "c", sep = "-")
paste(c("a", "b", "c"), sep = "-")
paste(c("a", "b", "c"), collapse = "-")
paste0("a", "b", "c")
paste0(c("a", "b", "c"))
paste(c("a", "b", "c"), collapse = "")

substr("abcdef", start = 2, stop = 4)
df = iris
head(df, 2)
df[, "Species_sub"] = substr(df$Species, 1, 3)
head(df, 2)

unique(df$Species_sub)
unique(df[, c("Species", "Species_sub")])
table(df$Species, df$Species_sub)

paste0("file_", 1:4, ".csv")
paste0("file_", sprintf(fmt = "%02d", 1:4), ".csv")

for(n_file in 1:4){
    print(paste0("file_", n_file, ".csv"))
}
for(n_file in 1:4){
    file_path = paste0("file_", n_file, ".csv")
    print(file_path)
}

bike = read.csv("bike.csv")
for(season in unique(bike$season)){
    bike_sub = bike[bike$season == season, ]
    write.csv(bike_sub, 
              paste0("bike_season_", season, ".csv"),
              row.names = FALSE)
}
file_list = list.files(pattern = "bike_season")
file_list

bike_bind = data.frame()
for(file_path in file_list){
    bike_sub = read.csv(file_path)
    print(nrow(bike_sub))
    bike_bind = rbind(bike_bind, bike_sub)
    print(paste0("bind: ", nrow(bike_bind)))
}

as.numeric("1,234")
as.numeric("1,234원")
as.numeric("1,234$")
as.numeric("1,234.456")
gsub(pattern = ",", replacement = "", "1,234.456")
num = gsub(pattern = ",", replacement = "", "1,234.456")
as.numeric(num)

as.numeric(gsub(pattern = "[^0-9.]", 
                replacement = "", "1,234.456원"))

dia = read.csv("diamonds.csv")
dia_tbl = table(dia$color, dia$clarity)
df_dia_tbl = as.data.frame(dia_tbl)

# [df_dia_tbl 객체를 기준으로 다음 문제를 풀이하시오.]
# Q1. 변수명을 "color", "clarity", "count"로 바꾸시오.
colnames(df_dia_tbl) = c("color" ,"clarity", "count")

# Q2. count의 최소값과 최대값을 확인하시오.
min(df_dia_tbl$count)
max(df_dia_tbl$count)
quantile(df_dia_tbl$count, probs = c(0, 1))

# Q3. count의 최소값에 해당하는 color와 clarity를 
#     차례대로 기술하시오.
df_dia_tbl[df_dia_tbl$count == 42, ]
df_dia_tbl[df_dia_tbl$count == min(df_dia_tbl$count), ]
df_dia_tbl[which.min(df_dia_tbl$count), ]
df_dia_tbl[which.min(df_dia_tbl$count), c("color", "clarity")]

# Q4. count의 최소값과 최대값을 각각 (데이터프레임)필터링을
#     실시하고, 두 데이터프레임을 bind 해서
#     df_minmax 객체에 저장하시오.
df_minmax = rbind(df_dia_tbl[which.min(df_dia_tbl$count), ],
                  df_dia_tbl[which.max(df_dia_tbl$count), ])
df_minmax


library("reshape2")
set.seed(123)
df = data.frame(Obs = 1:4,
                A = sample(10:99, size = 4),
                B = sample(10:99, size = 4),
                C = sample(10:99, size = 4))
df_melt = melt(data = df, id.vars = "Obs")
head(df_melt)

dcast(data = df_melt, formula = Obs ~ variable,
      value.var = "value")

elec = read.csv("elec_load.csv")
head(elec, 2)

# Q1. elec객체를 년/월/일 기준으로 melt() 함수를 적용하여
#    연산결과를 elec_melt 객체에 저장하시오.
elec_melt = melt(data = elec, 
                 id.vars = c("YEAR", "MONTH", "DAY"))
head(elec_melt)

elec_melt = melt(data = elec, 
                 id.vars = colnames(elec)[1:3])
head(elec_melt)

# Q2. 네 번째, 다섯 번째 변수명을 각각 "HOUR", "LOAD"로 변경
colnames(elec_melt)[c(4, 5)] = c("HOUR", "LOAD")
head(elec_melt, 2)

# Q3. HOUR 변수의 영문자를 제거하고 숫자만 남기시오.
unique(elec_melt$HOUR)
elec_melt[, "HOUR"] = gsub(pattern = "X", replacement = "",
                           elec_melt$HOUR)
elec_melt[, "HOUR"] = gsub(pattern = "HR", replacement = "",
                           elec_melt$HOUR)
head(elec_melt, 2)

# Q4. HOUR 변수의 속성(class)를 확인하시오.
class(elec_melt$HOUR)

# Q5. HOUR 변수의 속성을 숫자로 변경하고 결과를 확인하시오.
elec_melt[, "HOUR"] = as.numeric(elec_melt$HOUR)
class(elec_melt$HOUR)

head(elec_melt, 2)

elec_agg = aggregate(data = elec_melt,
                     LOAD ~ YEAR + MONTH, FUN = "mean")
elec_cast = dcast(data = elec_melt,
                  formula = YEAR ~ MONTH, 
                  value.var = "LOAD",
                  fun.aggregate = mean) # 텍스트 XX




