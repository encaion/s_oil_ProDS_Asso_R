dia = read.csv("diamonds.csv")
head(dia, 2)

table(dia[, c("cut", "color")])

dia = read.csv("diamonds.csv")
# Q1. 다이아몬드 가격이 900 이상인 데이터만 추출하여
#     dia_sub 객체에 저장하시오.
dia_sub = dia[dia$price >= 900, ]
nrow(dia)
nrow(dia_sub)

# Q2. dia_sub 기준, 색상이 "E" 이면서 투명도가 "VS1"인
#     다이아몬드 가격의 평균을 반올림하여 소수점 둘 째 자리
#     까지 표기하시오.
sub2 = dia_sub[(dia_sub$color == "E") & (dia_sub$clarity == "VS1"), ]
round(mean(sub2$price), 2)

# Q3. dia_sub 기준, 세공수준(cut)별 투명도별 다이아몬드 가격의
#     평균을 구하고 그 가격 평균값이 가장 높은 세공수준과
#     투명도를 차례대로 기술하시오.
dia_agg = aggregate(data = dia_sub, price ~ cut + clarity,
                    FUN = "mean")
dia_agg[dia_agg$price == max(dia_agg$price), 1:2]


elec = read.csv("elec_load.csv")
colnames(elec)
t(t(colnames(elec)))

ifelse(test = 1:4 >= 3, yes = "up!", no = "down!")

df = read.csv("rating_ramyun.csv")
head(df, 2)

df[, "kr"] = ifelse(test = df$Country == "South Korea",
                    yes = 1, no = 0)
head(df)

df = head(iris[, 1:4])
apply(X = df, MARGIN = 1, FUN = "sum")
apply(X = df, MARGIN = 2, FUN = "sum")

# apply(X = df, MARGIN = 2, FUN = "sum", na.rm = TRUE)
# ?head

score = read.csv("class_scores.csv")
head(score)

s_mean = apply(X = score[, 5:9], MARGIN = 2, FUN = "mean")
s_max = apply(score[, 5:9], 2, "max")
s_min = apply(score[, 5:9], 2, "min")
df_subject = data.frame(subject = colnames(score)[5:9],
                        mean = s_mean,
                        max = s_max,
                        min = s_min)
rownames(df_subject) = NULL
df_subject

source("data_generator_join.R", encoding = "UTF-8")
head(df_room)
head(df_list)

library("dplyr")
left_join(x = df_list, y = df_room,
          by = c("member" = "name"))
inner_join(x = df_list, y = df_room,
           by = c("member" = "name"))


factor(1:5)
factor(letters[2:5])
factor(1:5, labels = letters[1:5])
factor(1:5, labels = letters[1:5], ordered = TRUE)

fac = factor(1:5)
fac

fac[5] = 100
fac

factor(letters[2:5])
as.character(factor(letters[2:5]))
factor(c(100, 400, 600, 200))
as.numeric(factor(c(100, 400, 600, 200)))
as.numeric(as.character(factor(c(100, 400, 600, 200))))

as.POSIXct("2021-03-26")
as.POSIXct("2021-03-26 11:11:11")
as.POSIXct("2021-03-26 11")
as.POSIXct("2021/03/26")

as.Date("2021-03-26")
as.Date("2021-03-26 11")
as.Date("2021-03-26 11:11:11")

time = as.POSIXct("2021-03-26 11:11:11")
months(time)
months(time, abbreviate = TRUE)
weekdays(time)
weekdays(time, abbreviate = TRUE)
quarters(time)

strptime("2021년 3월 26일", 
         format = "%Y년 %m월 %d일")

time = as.POSIXct("2021-03-26 11:11:11")
library("lubridate")
year(time)
month(time)
day(time)
wday(time)
wday(time, label = TRUE)
wday(time, week_start = 1) # 한 주의 시작이 월요일
wday(time, week_start = 1, label = TRUE)
ymd(20210326)


c("a", "b", "c", "d") == c("b", "d")
c("a", "b", "c", "d") %in% c("b", "d")
sum(c("a", "b", "c", "d") %in% c("b", "d"))

dia = read.csv("diamonds.csv")
# Q1. price 변수의 IQR을 산출하여 소수점 둘 째 자리까지
#     기술하시오.
quantile(dia$price, probs = 0.25)
quantile(dia$price, probs = 0.75)

quantile(dia$price, probs = 0.75) - quantile(dia$price, probs = 0.25)
diff(quantile(dia$price, probs = c(0.25, 0.75)))

# Q2. IQR 범위 내에 들어가는 row 개수는?
q1 = quantile(dia$price, probs = 0.25)
q3 = quantile(dia$price, probs = 0.75)
dia_sub = dia[(dia$price > q1) & (dia$price < q3), ]
nrow(dia_sub)

sum((dia$price > q1) & (dia$price < q3))

data("Orange")
head(Orange)

set.seed(125)
df = as.matrix(Orange)
df[sample(1:(nrow(df) * ncol(df)), size = 20)] = NA
df = as.data.frame(df)
head(df, 3)
sapply(df, "class")

mean(df$age)
mean(df$age, na.rm = TRUE)
df[, "age"] = as.numeric(df$age)
head(df, 2)
df[is.na(df$age), "age"] = mean(df$age, na.rm = TRUE)
head(df, 2)

df[, "circumference"] = as.numeric(df$circumference)
df[is.na(df[, 3]), ] = mean(df[, 3], na.rm = TRUE)
head(df, 2)

vec = c(1, 2, NA, 7)
vec = ifelse(is.na(vec), yes = 6, no = vec)

df_na = data.frame(obs = 1:4,
                   value = c(1, 2, NA, 7))
df_na
df_na[, "value"] = ifelse(is.na(df_na$value),
                          yes = mean(df_na$value,
                                     na.rm = TRUE), 
                          no = df_na$value)
df_na



df = read.csv("iris_missing.csv")
head(df, 2)

library("data.table")
df = fread("iris_missing.csv", data.table = FALSE)
head(df, 2)

na_cnt = function(x){ # 1차원 벡터의 결측치 개수 확인
    sum(is.na(x))
}
apply(X = df, MARGIN = 2, FUN = "na_cnt") # UDF
apply(X = df, MARGIN = 2, 
      FUN = function(x){sum(is.na(x))}) # lambda 함수 


# install.packages("nortest")
library("nortest")
set.seed(123)
z = rnorm(100)
pearson.test(z) # nortest
shapiro.test(z) # 기본 함수

result = pearson.test(z)
class(result)
str(result)
result$p.value
result$statistic
round(result$p.value, 1)

hist(z)


cor(x = c(1, 2, 4, 5),
    y = c(2, 2, 3, 4))
cor.test(x = c(1, 2, 4, 5),
         y = c(2, 2, 3, 4))

cor.test(x = c(1, 2, 4, 5),
         y = c(2, 2, 3, 3))

bike = read.csv("bike.csv")
cor_mat = cor(bike[, 2:9])
round(cor_mat, 2)

# install.packages("corrplot")
library("corrplot")
corrplot(cor_mat)

# Q1. bike객체의 temp와 atemp의
#     등분산여부를 검정하고 p-value와 
#     귀무가설 기각여부를 기술하시오. (O, X)
# ※ var.test() 활용 
var.test(bike$temp, bike$atemp)
var(bike$temp)
var(bike$atemp)

var.test(bike[, c("temp", "atemp")])

# Q1. season별 casual의 등분산성을 검정하시오.
bartlett.test(data = bike,
              casual ~ season)

# Q2. season별 casual의 분산을 확인하시오.
aggregate(data = bike, casual ~ season,
          FUN = "var")

# Q3. season별 count의 분산을 확인하고
#     가장 분산이 큰 두 season을 골라
#     등분산 검정을 실시하고
#     검정통계량 및 귀무가설 기각여부를
#     기술하시오.
# ※ 필수 사용: %in%, order(), var.test()
bike_agg = aggregate(data = bike,
                     count ~ season, 
                     FUN = "var")
bike_agg = bike_agg[order(bike_agg$count,
                          decreasing = TRUE), ]
bike_sub = bike[bike$season %in% c(3, 2), ]
bike_sub = bike[(bike$season == 3) | (bike$season == 2), ]
bike_sub = bike[bike$season %in% bike_agg[1:2, "season"], ]

var.test(bike_sub[bike_sub$season == 2, "count"],
         bike_sub[bike_sub$season == 3, "count"])

var.test(bike[bike$season == 2, "count"],
         bike[bike$season == 3, "count"])

# p-value가 유의수준(0.05)보다 크기 때문에
# 귀무가설을 기각하지 못함. 즉, 두 집단의
# 분산이 같다. 또는 같은 것이나 다름 없다.

?chisq.test()
df = read.csv("diabetes.csv")
head(df, 2)

# Q. 혈당(Glucose) 126이상 여부와
#    당뇨병 발병여부간 독립성 검정을 실시하고자 한다.
#    이 때 혈당이 40 미만인 데이터를 제외하고
#    검정을 실시하며, 검정 결과를 확인하시오.
sum(df$Glucose < 40)
df_sub = df[df$Glucose >= 40, ]
df_sub[, "g_GE126"] = ifelse(df_sub$Glucose >= 126,
                             yes = 1, no = 0)
table(df_sub[, c("g_GE126", "Outcome")]) # ★★★
chisq.test(table(df_sub[, c("g_GE126", "Outcome")]))
# p-value가 유의수준(0.05)보다 작기 때문에
# 귀무가설을 기각하고 대립가설을 채택하여,
# 두 집단은 서로 독립이 아니(연관O)라고 할 수 있음

set.seed(123)
t.test(x = rnorm(300), mu = 0) # mu <-- 모평균

set.seed(123)
nums = rnorm(200)
t.test(nums, mu = 0.2)

# Q. bike.csv파일을 읽어와서 2012년 1월 데이터만 추출하여
#    casual과 registered 변수간 대응표본 t-검정을
#    실시하고 검정통계량을 반올림하여 소수점 첫 째 자리
#    까지 기술하시오.
bike = read.csv("bike.csv")
head(bike, 2)

library("lubridate")
bike[, "year" ] =  year(bike$datetime)
bike[, "month"] = month(bike$datetime)
head(bike, 2)

bike_1201 = bike[(bike$year == 2012) & (bike$month == 1), ]
head(bike_1201, 2)

t.test(bike_1201$casual, bike_1201$registered,
       paired = TRUE)
t.test(bike_1201$registered, bike_1201$casual,
       paired = TRUE)


t.test(bike[bike$season == 1, "registered"],
       bike[bike$season == 3, "registered"],
       paired = FALSE,
       var.equal = FALSE)
# 이분산, 독립 2표본 t-검정

model1 = aov(casual ~ season,
             data = bike) # season을 연속으로 간주
summary(model1) # 독립변수의 자유도 1

model2 = aov(casual ~ as.character(season),
             data = bike) # season 명목
summary(model2) # 독립변수의 자유도 3(4 - 1)

TukeyHSD(model2, which = "as.character(season)")

dia = read.csv("diamonds.csv")
model3 = aov(data = dia, price ~ color)
summary(model3)
TukeyHSD(model3, which = "color")


library("ggplot2")
set.seed(123)
df = data.frame(xx = 1:10,
                yy = sample(1:10, size = 10))
ggplot(data = df,
       aes(x = xx, y = yy)) + 
    geom_point()

ggplot(data = df,
       aes(x = xx, y = yy)) + 
    geom_point(size = 5)


ggplot(data = df,
       aes(x = xx, y = yy)) + 
    geom_point(size = 8)

ggplot(data = df,
       aes(x = xx, y = yy)) + 
    geom_point(size = 8) + 
    geom_line()

ggplot(data = df,
       aes(x = xx, y = yy)) + 
    geom_point(size = 8) + 
    geom_line() + 
    theme_bw()

ggplot(data = df,
       aes(x = xx, y = yy)) + 
    geom_point(size = 8) + 
    geom_line() + 
    geom_point(color = "#FFFFFF",
               size = 6) + 
    theme_bw()

ggplot(data = df,
       aes(x = xx, y = yy)) + 
    geom_point(size = 8) + 
    geom_line(size = 1.3) + 
    geom_point(color = "#FFFFFF",
               size = 6) + 
    theme_bw()

ggplot(data = df,
       aes(x = xx, y = yy)) + 
    geom_point(size = 8) + 
    geom_line(size = 1.3) + 
    geom_point(color = "#FFFFFF",
               size = 6) + 
    geom_hline(yintercept = 8, color = "#FF0000",
               size = 2) + 
    theme_bw()

ggplot(data = df,
       aes(x = xx, y = yy)) + 
    geom_hline(yintercept = 8, color = "#FF0000",
               size = 2) + 
    geom_point(size = 8) + 
    geom_line(size = 1.3) + 
    geom_point(color = "#FFFFFF",
               size = 6) + 
    theme_bw()

ggplot(data = df,
       aes(x = xx, y = yy)) + 
    geom_hline(yintercept = 8, color = "#FF0000",
               size = 2) + 
    geom_point(size = 8) + 
    geom_line(size = 1.3) + 
    geom_point(color = "#FFFFFF",
               size = 6) + 
    annotate(geom = "text", x = 9.5, y = 8.5,
             label = "Warning") + 
    theme_bw()

ggplot(data = df,
       aes(x = xx, y = yy)) + 
    geom_col()

ggplot(data = df,
       aes(x = xx, y = yy,
           fill = yy)) + 
    geom_col()

ggplot(data = df,
       aes(x = xx, y = yy,
           fill = yy)) + 
    geom_col() + 
    theme(legend.position = "none")


# install.packages("fastDummies")
library("fastDummies")
df = read.csv("diamonds.csv")
df_dum1 = dummy_cols(df[, c("price", "cut")],
                     select_columns = "cut")
head(df_dum1, 2)
# Very Good의 경우 띄어쓰기가 있기 때문에
# 향후 코드 작성시 문제가 발생할 수 있음.
# colnames() 함수 활용하여 제거 요망

df_dum2 = dummy_cols(df[, c("price", "cut")],
                     select_columns = "cut",
                     remove_first_dummy = TRUE)
head(df_dum2, 2)

df_dum3 = dummy_cols(df[, c("price", "cut")],
                     select_columns = "cut",
                     remove_first_dummy = TRUE,
                     remove_selected_columns = TRUE) # 권장
head(df_dum3, 2)

#### 선형회귀 ####
dia = read.csv("diamonds.csv")
dia = dia[, c(1:2, 6:7)]
head(dia, 2)

library("fastDummies")
dia_dum = dummy_cols(dia, select_columns = "cut",
                     remove_first_dummy = TRUE,
                     remove_selected_columns = TRUE)
head(dia_dum, 2)
dia_dum_tr = dia_dum[1:50000, ]
dia_dum_te = dia_dum[50001:nrow(dia_dum), ]
model = lm(price ~ ., data = dia_dum_tr)
summary(model)

library("car")
vif(model)

pred = predict(model, newdata = dia_dum_te)
head(pred)

library("Metrics")
rmse(actual = dia_dum_te$price,
     predicted = pred)

#### 로지스틱 회귀 ####
df = iris
df[, "Species"] = ifelse(df$Species == "virginica", 1, 0)
model = glm(Species ~ ., data = df, family = "binomial")
summary(model)

pred = predict(model, newdata = df, type = "response")
ifelse(pred >= 0.5, 1, 0)
pred_class = ifelse(pred >= 0.5, 1, 0) # 0.5는 분류 임계값
table(df$Species, pred_class) # 예측분류 상태 확인
accuracy(actual = df$Species, predicted = pred_class) # 분류값
auc(actual = df$Species, predicted = pred) # 반드시 확률값
round(exp(model$coefficients), 3) # Odds Ratio