5 %/% 2
# 5 %/% 2
# 주석(comment)
4^2 # 4의 2승

#### 문제 1 ####
2 + 2

#### 문제 2 ####
1 + 1

#### 문제 3 ####

head.matrix()

df = iris

# install.packages("beepr")
library("beepr")
beep(2)
beepr::beep(2)

library("dataaa")
library("data.table")

getwd()
?getwd

aws = read.delim("AWS_sample.txt",
                 sep = "#", 
                 stringsAsFactors = FALSE)
head(aws)

df = read.csv("bike.csv")
head(df, 2)

library("data.table")
df = fread("bike.csv")
head(df, 2)

# install.packages("readxl")
library("readxl")
df = read_excel("iris_xlsx.xlsx")
head(df, 2)

df = read.delim("bike.csv", sep = ",")
head(df, 2)


write.csv(df, "write_csv_sample_1.csv")
write.csv(df, "write_csv_sample_2.csv",
          row.names = FALSE)

# install.packages("xlsx")
# install.packages("rJava")
# java_home 을 찾을 수 없습니다.
# library("xlsx")

# install.packages("writexl")
library("writexl")
write_xlsx(df, "excel_write_sample.xlsx")

123456789
400^3
0.003^3
"abc"
'abc'
"abc'aaa"
# 'abc'aaa'
'abc\'aaa'

TRUE
FALSE
TRUE + FALSE
TRUE + TRUE
TRUE + FALSE + TRUE

c(1, 2, 3)
c(1, 3, "a")
aa = c(2, 4, 6)
aa
aa[1]
aa[c(1, 3)]
aa[2] = "kkk"
aa
bb = aa # aa 객체 내용(전체)을 bb 객체로 복사(할당)
bb

# 대괄호 --> 색인, 추출

matrix(c(1, 2, 3, 4))
matrix(c(1, 2, 3, 4), nrow = 2)
matrix(c(1, 2, 3, 4), ncol = 2)
matrix(c(1, 2, 3, 4), nrow = 2, byrow = TRUE)
mat = matrix(c(1, 2, 3, 4), nrow = 2)
mat[1, ]
mat[, 1]
mat[1, 2]

mat[1, c(1, 2)] # mat[1, ] 와 같음

# install.packages("imager")
library("imager")
img = load.image("sample_cat_image.jpg")
img[1:3, 1:3, 1, 1]
plot(img)
dim(img)
443 * 532

img[,,, 1] = 1 - img[,,, 1]
plot(img)

img[,,, 2] = 1 - img[,,, 2]
img[,,, 3] = 1 - img[,,, 3]
plot(img)

data.frame(aa = c(1, 2, 3),
           bb = c("a", "b", "c"))
data.frame(aa = c(1, 2, 3),
           bb = c("a", "b"))
df = data.frame(aa = c(1, 2, 3),
                bb = c("a", "b", "c"))
df
df$aa
df[, "aa"]
df[, 1]
# data.frame[ row , column ]

c(1, 2, 3, 4)
1:4
3:-3
seq(1, 3)
seq(1, 3, 1)
seq(from = 1, to = 3)
seq(from = 1, to = 3, by = 1)

rep(1:3, 4)
rep(4, 1:3)
rep(x = 1:3, times = 4)
rep(times = 4, x = 1:3)

aws = read.csv("AWS_sample.txt", sep = "#")
head(aws) # 첫 6개 row
tail(aws) # 마지막 6개 row
head(aws, 2) # 첫 2개 row
str(aws) # 객체 구조
summary(aws) # 객체 요약 
nrow(aws) # row 개수
ncol(aws) # column 개수
colnames(aws) # 변수명(column명) 출력

?head
head(aws, n = 10L)
head(aws, n = 10)
head(aws, 10)

c("AWS_ID", "TM", "TA", "Wind", "X.")
colnames(aws)
# Q. 원소 TM과 Wind를 추출하는 코드를 작성하시오
vec = colnames(aws)
vec[c(2, 4)]
colnames(aws)[c(2, 4)]

aws[2, ]
aws[135, ]
aws[3:10, ]
aws[c(2, 135, 3:10), ]
aws_sub = aws[c(2, 135, 3:10), ]
aws_sub


aws[, 1]
aws[, 3]
aws[, c(1, 3)]
aws[, c("AWS_ID", "TA")]

aws[995, 3]
aws[, 3][995]

aws[c(1, 3), "Wind"]
aws[c(2, 4), c("Wind", "AWS_ID")]
aws[1:3, -5] # 다섯 번째 column을 제외하고~
aws[1:3, -c(2, 4)]

aws[1:3, -3]
aws[1:3, c(1, 2, 4, 5)]
aws[1:3, c(1:2, 4:5)]

aws[1, ] = -1
head(aws)

aws[1:2, ] = -33
head(aws)

aws["6", ] = -4
head(aws)

aws[c(1:2, 6), ] = -6666
head(aws)

aws[1, 2]
aws[1, 2, 3]
aws[1, 2, 3, 4]

# 2 + 4
# `+`(2, 4)
# `[`(aws, i = c(1, 3), j = c(1, 3))

aws[ , 6] = "new"
aws[ , ncol(aws) + 1] = "new!!!"
head(aws, 2)

colnames(aws)
# Q1. aws객체의 6, 7번째 변수명을 각각
#     "aa", "bb" 로 변경하시오(두 줄의 코드)
colnames(aws)[6]
colnames(aws)[6] = "aa"
colnames(aws)[7] = "bb"
colnames(aws)

# Q2. aws객체의 6, 7번째 변수명을 각각
#     "aa", "bb" 로 변경하시오(한 줄의 코드)
colnames(aws)[c(6, 7)] = c("aa", "bb")
colnames(aws)[6:7] = c("aa", "bb")

# colnames(aws[, c(6, 7)]) = c("aa", "bb") # XXXX

aws[, "last_one"] = 12345
head(aws, 2)

aws$last_one = 99999
head(aws, 2)

aws$newnew = 3333
head(aws, 2)

# aws[, "newnew"] = 3333

df1 = data.frame(aa = 1:2,
                 bb = c("a", "b"))
df2 = data.frame(aa = 4:5,
                 bb = c("c", "d"),
                 cc = 6:7)
rbind(df1, df2)

df1 = data.frame(aa = 1:2,
                 bb = c("a", "b"))
df2 = data.frame(aa = 4:5,
                 kk = c("c", "d"))
rbind(df1, df2)